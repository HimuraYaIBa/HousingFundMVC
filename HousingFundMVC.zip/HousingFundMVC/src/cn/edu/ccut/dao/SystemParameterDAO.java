package cn.edu.ccut.dao;

import cn.edu.ccut.mapper.SystemParameterMapper;
import cn.edu.ccut.po.SystemParameter;
import cn.edu.ccut.util.InitialSqlSession;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class SystemParameterDAO {

    public List<SystemParameter> selectAll() {
        SqlSession session = InitialSqlSession.openSqlSession();
        SystemParameterMapper systemParameterMapper = session.getMapper(SystemParameterMapper.class);
        List<SystemParameter> systemParameter = systemParameterMapper.selectallintosystemparameter();
        session.commit();
        session.close();
        return systemParameter;
    }

    public int insert(String SEQNAME, String DESCE, String FREEUSE1) {
        SqlSession session = InitialSqlSession.openSqlSession();
        SystemParameterMapper systemParameterMapper = session.getMapper(SystemParameterMapper.class);
        int systemParameter = systemParameterMapper.insertintosystemparameter(SEQNAME, DESCE, FREEUSE1);
        session.commit();
        session.close();
        return systemParameter;
    }

    public int update(String SEQNAME, String DESCE, String FREEUSE1, int SEQ) {
        SqlSession session = InitialSqlSession.openSqlSession();
        SystemParameterMapper systemParameterMapper = session.getMapper(SystemParameterMapper.class);
        int systemParameter = systemParameterMapper.updateintosystemparameter(SEQNAME, DESCE, FREEUSE1, SEQ);
        session.commit();
        session.close();
        return systemParameter;
    }

    public List<SystemParameter> select(int SEQ) {
        SqlSession session = InitialSqlSession.openSqlSession();
        SystemParameterMapper systemParameterMapper = session.getMapper(SystemParameterMapper.class);
        List<SystemParameter> systemParameter = systemParameterMapper.selectintosystemparameter(SEQ);
        session.commit();
        session.close();
        return systemParameter;
    }

    public int delete(int SEQ) {
        SqlSession session = InitialSqlSession.openSqlSession();
        SystemParameterMapper systemParameterMapper = session.getMapper(SystemParameterMapper.class);
        int systemParameter = systemParameterMapper.deleteintosystemparameter(SEQ);
        session.commit();
        session.close();
        return systemParameter;
    }

    public List<SystemParameter> selectAllUNITACCNUM() {
        SqlSession session = InitialSqlSession.openSqlSession();
        SystemParameterMapper systemParameterMapper = session.getMapper(SystemParameterMapper.class);
        List<SystemParameter> systemParameter = systemParameterMapper.selectUNITACCNUMintoworkunit();
        session.commit();
        session.close();
        return systemParameter;
    }








    public int findTotalCount() {
        SqlSession session = InitialSqlSession.openSqlSession();
        SystemParameterMapper systemParameterMapper = session.getMapper(SystemParameterMapper.class);
        int pageperosn = systemParameterMapper.findTotalCount();
        session.commit();
        session.close();
        return pageperosn;
    }

    public List<SystemParameter> findByPage(int start, int rows) {
        SqlSession session = InitialSqlSession.openSqlSession();
        SystemParameterMapper systemParameterMapper = session.getMapper(SystemParameterMapper.class);
        List<SystemParameter> systemParameter = systemParameterMapper.findByPage(start,rows);
        session.commit();
        session.close();
        return systemParameter;
    }



}
