package cn.edu.ccut.dao;

import cn.edu.ccut.mapper.LoginMapper;
import cn.edu.ccut.po.Login;
import cn.edu.ccut.util.InitialSqlSession;
import org.apache.ibatis.session.SqlSession;

public class LoginDAO {
    public Login query(String username,String password){
        SqlSession session = InitialSqlSession.openSqlSession();
        LoginMapper loginMapper = session.getMapper(LoginMapper.class);
        Login login = loginMapper.queryByUsernameAndPassword(username,password);
        session.close();
        return login;
    }
}
