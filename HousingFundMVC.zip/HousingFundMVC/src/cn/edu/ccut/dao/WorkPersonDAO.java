package cn.edu.ccut.dao;

import cn.edu.ccut.mapper.WorkPersonMapper;
import cn.edu.ccut.po.Pager;
import cn.edu.ccut.po.WorkPerson;
import cn.edu.ccut.util.InitialSqlSession;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class WorkPersonDAO {

    public List<WorkPerson> select(int UNITACCNUM) {
        SqlSession session = InitialSqlSession.openSqlSession();
        WorkPersonMapper workPersonMapper = session.getMapper(WorkPersonMapper.class);
        List<WorkPerson> workPerson = workPersonMapper.selectintoworkperson(UNITACCNUM);
        session.commit();
        session.close();
        return workPerson;
    }

    public int insert(int ACCNUM, int UNITACCNUM, String UNITACCNAME, double UNITPROP, double PERPROP, String USERNAME, int DOCUMENTTYPE, double BASENUMBER, String DOCUMENTNUMBER) {
        SqlSession session = InitialSqlSession.openSqlSession();

        WorkPersonMapper workPersonMapper = session.getMapper(WorkPersonMapper.class);
        int workPerson = workPersonMapper.insertintoworkperson(ACCNUM, UNITACCNUM, UNITACCNAME, UNITPROP, PERPROP, USERNAME, DOCUMENTTYPE, BASENUMBER, DOCUMENTNUMBER);
        session.commit();
        session.close();
        return workPerson;
    }

    public List<WorkPerson> selectACCNUM(int ACCNUM) {
        SqlSession session = InitialSqlSession.openSqlSession();
        WorkPersonMapper workPersonMapper = session.getMapper(WorkPersonMapper.class);
        List<WorkPerson> workPerson = workPersonMapper.selectintoworkpersonACCNUM(ACCNUM);
        session.commit();
        session.close();
        return workPerson;
    }


    public int update(String USERNAME, int DOCUMENTTYPE, String DOCUMENTNUMBER, int ACCNUM) {
        SqlSession session = InitialSqlSession.openSqlSession();

        WorkPersonMapper workPersonMapper = session.getMapper(WorkPersonMapper.class);
        int workPerson = workPersonMapper.updateintoworkperson(USERNAME, DOCUMENTTYPE, DOCUMENTNUMBER, ACCNUM);
        session.commit();
        session.close();
        return workPerson;
    }


    public List<WorkPerson> selectAll() {
        SqlSession session = InitialSqlSession.openSqlSession();
        WorkPersonMapper workPersonMapper = session.getMapper(WorkPersonMapper.class);
        List<WorkPerson> workPerson = workPersonMapper.selectallintoworkperson();
        session.commit();
        session.close();
        return workPerson;
    }









    public int findTotalCount() {
        SqlSession session = InitialSqlSession.openSqlSession();
        WorkPersonMapper workPersonMapper = session.getMapper(WorkPersonMapper.class);
        int pageperosn = workPersonMapper.findTotalCount();
        session.commit();
        session.close();
        return pageperosn;
    }

    public List<WorkPerson> findByPage(int start, int rows) {
        SqlSession session = InitialSqlSession.openSqlSession();
        WorkPersonMapper workPersonMapper = session.getMapper(WorkPersonMapper.class);
        List<WorkPerson> workPerson = workPersonMapper.findByPage(start,rows);
        session.commit();
        session.close();
        return workPerson;
    }





}
