package cn.edu.ccut.dao;

import cn.edu.ccut.mapper.WorkUnitMapper;
import cn.edu.ccut.po.SystemParameter;
import cn.edu.ccut.po.WorkUnit;
import cn.edu.ccut.util.InitialSqlSession;
import org.apache.ibatis.session.SqlSession;

import java.util.List;


public class WorkUnitDAO {

    public int insert(int UNITACCNUM,String UNITACCNAME, String UNITADDR, String ORGCODE, String UNITCHAR, String UNITKIND
            , String SALARYDATE, String UNITPHONE, String UNITLINKMAN, String UNITAGENTPAPNO, double UNITPROP, double PERPROP, String LASTPAYDATE, String REMARK) {
        SqlSession session = InitialSqlSession.openSqlSession();

        WorkUnitMapper workUnitMapper = session.getMapper(WorkUnitMapper.class);
        int workUnit = workUnitMapper.insertintoworkunit(UNITACCNUM,UNITACCNAME, UNITADDR, ORGCODE, UNITCHAR, UNITKIND, SALARYDATE,
                UNITPHONE, UNITLINKMAN, UNITAGENTPAPNO, UNITPROP, PERPROP, LASTPAYDATE, REMARK);
        session.commit();
        session.close();
        return workUnit;
    }


    public int update(String UNITACCNAME, String UNITADDR, String ORGCODE, String UNITCHAR, String UNITKIND
            , String SALARYDATE, String UNITPHONE, String UNITLINKMAN, String UNITAGENTPAPNO, double UNITPROP, double PERPROP, String LASTPAYDATE, String REMARK, int UNITACCNUM) {
        SqlSession session = InitialSqlSession.openSqlSession();

        WorkUnitMapper workUnitMapper = session.getMapper(WorkUnitMapper.class);
        int workUnit = workUnitMapper.updateintoworkunit(UNITACCNAME, UNITADDR, ORGCODE, UNITCHAR, UNITKIND, SALARYDATE,
                UNITPHONE, UNITLINKMAN, UNITAGENTPAPNO, UNITPROP, PERPROP, LASTPAYDATE, REMARK, UNITACCNUM);

        session.commit();
        session.close();
        return workUnit;
    }


    public List<WorkUnit> select(int UNITACCNUM) {
        SqlSession session = InitialSqlSession.openSqlSession();
        WorkUnitMapper workUnitMapper = session.getMapper(WorkUnitMapper.class);
        List<WorkUnit> workUnit = workUnitMapper.selectintoworkunit(UNITACCNUM);
        session.commit();
        session.close();
        return workUnit;
    }


    public List<WorkUnit> selectAll() {
        SqlSession session = InitialSqlSession.openSqlSession();
        WorkUnitMapper workUnitMapper = session.getMapper(WorkUnitMapper.class);
        List<WorkUnit> workUnit = workUnitMapper.selectallintoworkunit();
        session.commit();
        session.close();
        return workUnit;
    }




    public int findTotalCount() {
        SqlSession session = InitialSqlSession.openSqlSession();
        WorkUnitMapper workUnitMapper = session.getMapper(WorkUnitMapper.class);
        int pageperosn = workUnitMapper.findTotalCount();
        session.commit();
        session.close();
        return pageperosn;
    }

    public List<WorkUnit> findByPage(int start, int rows) {
        SqlSession session = InitialSqlSession.openSqlSession();
        WorkUnitMapper workUnitMapper = session.getMapper(WorkUnitMapper.class);
        List<WorkUnit> workPerson = workUnitMapper.findByPage(start,rows);
        session.commit();
        session.close();
        return workPerson;
    }


    public List<WorkUnit> selectAllUNITACCNUM() {

        SqlSession session = InitialSqlSession.openSqlSession();
        WorkUnitMapper workUnitMapper = session.getMapper(WorkUnitMapper.class);
        List<WorkUnit> workUnit = workUnitMapper.selectUNITACCNUMintoworkperson();
        session.commit();
        session.close();
        return workUnit;

    }
}