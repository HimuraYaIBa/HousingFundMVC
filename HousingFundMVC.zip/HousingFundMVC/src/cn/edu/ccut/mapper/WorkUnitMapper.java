package cn.edu.ccut.mapper;

import cn.edu.ccut.po.WorkUnit;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface WorkUnitMapper {


    @Insert("insert into tb002 (UNITACCNUM,UNITACCNAME,UNITADDR,ORGCODE,UNITCHAR,UNITKIND,SALARYDATE,UNITPHONE," +
            "UNITLINKMAN,UNITAGENTPAPNO,UNITPROP,PERPROP,LASTPAYDATE,REMARK) values(#{UNITACCNUM},#{UNITACCNAME},#{UNITADDR}," +
            "#{ORGCODE},#{UNITCHAR},#{UNITKIND},#{SALARYDATE},#{UNITPHONE},#{UNITLINKMAN}," +
            "#{UNITAGENTPAPNO},#{UNITPROP},#{PERPROP},#{LASTPAYDATE},#{REMARK})")
    int insertintoworkunit(@Param("UNITACCNUM") int UNITACCNUM, @Param("UNITACCNAME") String UNITACCNAME, @Param("UNITADDR") String UNITADDR
            , @Param("ORGCODE") String ORGCODE, @Param("UNITCHAR") String UNITCHAR, @Param("UNITKIND") String UNITKIND
            , @Param("SALARYDATE") String SALARYDATE, @Param("UNITPHONE") String UNITPHONE, @Param("UNITLINKMAN") String UNITLINKMAN
            , @Param("UNITAGENTPAPNO") String UNITAGENTPAPNO, @Param("UNITPROP") double UNITPROP, @Param("PERPROP") double PERPROP
            , @Param("LASTPAYDATE") String LASTPAYDATE, @Param("REMARK") String REMARK);
    //新增


    @Update("update tb002 set UNITACCNAME=#{UNITACCNAME},UNITADDR=#{UNITADDR},ORGCODE=#{ORGCODE},UNITCHAR=#{UNITCHAR}" +
            ",UNITKIND=#{UNITKIND},SALARYDATE=#{SALARYDATE},UNITPHONE=#{UNITPHONE},UNITLINKMAN=#{UNITLINKMAN}," +
            "UNITAGENTPAPNO=#{UNITAGENTPAPNO},UNITPROP=#{UNITPROP},PERPROP=#{PERPROP},LASTPAYDATE=#{LASTPAYDATE},REMARK=#{REMARK} where UNITACCNUM=#{UNITACCNUM}")
    int updateintoworkunit(@Param("UNITACCNAME") String UNITACCNAME, @Param("UNITADDR") String UNITADDR
            , @Param("ORGCODE") String ORGCODE, @Param("UNITCHAR") String UNITCHAR, @Param("UNITKIND") String UNITKIND
            , @Param("SALARYDATE") String SALARYDATE, @Param("UNITPHONE") String UNITPHONE, @Param("UNITLINKMAN") String UNITLINKMAN
            , @Param("UNITAGENTPAPNO") String UNITAGENTPAPNO, @Param("UNITPROP") double UNITPROP, @Param("PERPROP") double PERPROP
            , @Param("LASTPAYDATE") String LASTPAYDATE, @Param("REMARK") String REMARK, @Param("UNITACCNUM") int UNITACCNUM);
    //修改

    @Select("select * from tb002 where UNITACCNUM = #{UNITACCNUM}")
    List<WorkUnit> selectintoworkunit(@Param("UNITACCNUM") int UNITACCNUM);
    //查询单个


    @Select("select * from tb002")
    List<WorkUnit> selectallintoworkunit();
    //查询全部







    /*
    WorkUnit的分页
    */
    @Select("select count(*) from tb002")
    int findTotalCount();

    @Select("select * from tb002 limit #{start} , #{rows}")
    List<WorkUnit> findByPage(@Param("start") int start, @Param("rows") int rows);


    @Select("SELECT UNITACCNUM FROM tb002")
    List<WorkUnit> selectUNITACCNUMintoworkperson();
    //查询列表


}

/*
    @Select("insert into tb002 where UNITACCNAME = #{username} and password = '${password}'")
UNITACCNAME
UNITADDR
ORGCODE
UNITCHAR
UNITKIND
SALARYDATE
UNITPHONE
UNITLINKMAN
UNITAGENTPAPNO
UNITPROP
PERPROP
LASTPAYDATE
REMARK
*/
