package cn.edu.ccut.mapper;

import cn.edu.ccut.po.SystemParameter;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface SystemParameterMapper {

    @Select("select * from tb001")
    List<SystemParameter> selectallintosystemparameter();
    //查询全部

    @Insert("insert into tb001 (SEQNAME,DESCE,FREEUSE1) values(#{SEQNAME},#{DESCE},#{FREEUSE1})")
    int insertintosystemparameter(@Param("SEQNAME") String SEQNAME,
                                  @Param("DESCE") String DESCE, @Param("FREEUSE1") String FREEUSE1);
    //新增

    @Update("update tb001 set SEQNAME=#{SEQNAME},DESCE=#{DESCE},FREEUSE1=#{FREEUSE1} where SEQ=#{SEQ}")
    int updateintosystemparameter(@Param("SEQNAME") String SEQNAME, @Param("DESCE") String DESCE, @Param("FREEUSE1") String FREEUSE1, @Param("SEQ") int SEQ);
    //修改

    @Select("select * from tb001 where SEQ=#{SEQ}")
    List<SystemParameter> selectintosystemparameter(@Param("SEQ") int SEQ);
    //查询单个

    @Delete("DELETE FROM tb001 WHERE SEQ=#{SEQ}")
    int deleteintosystemparameter(@Param("SEQ") int SEQ);
    //删除

    @Select("SELECT SEQ FROM tb001")
    List<SystemParameter> selectUNITACCNUMintoworkunit();
    //查询指定行的数值






    /*
    SystemParameter的分页
    */
    @Select("select count(*) from tb001")
    int findTotalCount();

    @Select("select * from tb001 limit #{start} , #{rows}")
    List<SystemParameter> findByPage(@Param("start") int start, @Param("rows") int rows);
    //查询列表


}
