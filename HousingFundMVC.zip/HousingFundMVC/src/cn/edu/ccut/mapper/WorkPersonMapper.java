package cn.edu.ccut.mapper;

import cn.edu.ccut.po.WorkPerson;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface WorkPersonMapper {

    @Select("select * from tb002 where UNITACCNUM = #{UNITACCNUM}")
    List<WorkPerson> selectintoworkperson(@Param("UNITACCNUM") int UNITACCNUM);
    //查询单个


    @Insert("insert into tb003 (ACCNUM,UNITACCNUM,UNITACCNAME,UNITPROP,PERPROP,USERNAME,DOCUMENTTYPE,BASENUMBER,DOCUMENTNUMBER)" +
            " values(#{ACCNUM},#{UNITACCNUM},#{UNITACCNAME},#{UNITPROP},#{PERPROP},#{USERNAME},#{DOCUMENTTYPE},#{BASENUMBER},#{DOCUMENTNUMBER})")
    int insertintoworkperson(@Param("ACCNUM") int ACCNUM, @Param("UNITACCNUM") int UNITACCNUM, @Param("UNITACCNAME") String UNITACCNAME, @Param("UNITPROP") double UNITPROP,
                             @Param("PERPROP") double PERPROP, @Param("USERNAME") String USERNAME, @Param("DOCUMENTTYPE") int DOCUMENTTYPE,
                             @Param("BASENUMBER") double BASENUMBER, @Param("DOCUMENTNUMBER") String DOCUMENTNUMBER);
    //新增

    @Select("select * from tb003 where ACCNUM = #{ACCNUM}")
    List<WorkPerson> selectintoworkpersonACCNUM(@Param("ACCNUM") int ACCNUM);
    //查询单个

    @Update("update tb003 set USERNAME=#{USERNAME},DOCUMENTTYPE=#{DOCUMENTTYPE},DOCUMENTNUMBER=#{DOCUMENTNUMBER} where ACCNUM=#{ACCNUM}")
    int updateintoworkperson(@Param("USERNAME") String USERNAME, @Param("DOCUMENTTYPE") int DOCUMENTTYPE, @Param("DOCUMENTNUMBER") String DOCUMENTNUMBER, @Param("ACCNUM") int ACCNUM);
    //修改


    @Select("select * from tb003")
    List<WorkPerson> selectallintoworkperson();
    //查询全部





    /*
    WorkPerson的分页
    */
    @Select("select count(*) from tb003")
    int findTotalCount();

    @Select("select * from tb003 limit #{start} , #{rows}")
    List<WorkPerson> findByPage(@Param("start") int start, @Param("rows") int rows);
    //查询列表


}
