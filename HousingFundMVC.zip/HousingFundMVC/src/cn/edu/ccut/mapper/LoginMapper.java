package cn.edu.ccut.mapper;

import cn.edu.ccut.po.Login;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface LoginMapper {
    @Select("select * from t_login where username = #{username} and password = '${password}'")
    Login queryByUsernameAndPassword(@Param("username") String username, @Param("password") String password);
}
