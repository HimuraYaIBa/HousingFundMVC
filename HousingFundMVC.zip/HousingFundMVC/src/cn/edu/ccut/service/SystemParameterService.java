package cn.edu.ccut.service;

import cn.edu.ccut.dao.SystemParameterDAO;
import cn.edu.ccut.po.Pager;
import cn.edu.ccut.po.SystemParameter;

import java.util.List;

public class SystemParameterService {

    public List<SystemParameter> selectAllsystemParameter() {
        SystemParameterDAO dao = new SystemParameterDAO();
        List<SystemParameter> selectallsystemParameter = dao.selectAll();
        System.out.println("selectallsystemParameter:::::::::::" + selectallsystemParameter);
        if (selectallsystemParameter != null) {
            return selectallsystemParameter;
        } else {
            return null;
        }

    }


    public boolean insertsystemParameter(SystemParameter systemParameter) {
        SystemParameterDAO dao = new SystemParameterDAO();
        Integer count = dao.insert(systemParameter.getSEQNAME(), systemParameter.getDESCE(), systemParameter.getFREEUSE1());
        if (count > 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean updateworksystemParameter(SystemParameter systemParameter) {
        SystemParameterDAO dao = new SystemParameterDAO();
        Integer count = dao.update(systemParameter.getSEQNAME(), systemParameter.getDESCE(), systemParameter.getFREEUSE1(), systemParameter.getSEQ());
        if (count > 0) {
            return true;
        } else {
            return false;
        }
    }


    public List<SystemParameter> selectsystemParameter(SystemParameter systemParameter) {
        SystemParameterDAO dao = new SystemParameterDAO();
        List<SystemParameter> selectsystemParameter = dao.select(systemParameter.getSEQ());
        System.out.println("selectsystemParameter:::::::::::" + selectsystemParameter);
        if (selectsystemParameter != null) {
            return selectsystemParameter;
        } else {
            return null;
        }

    }

    public boolean deletesystemParameter(SystemParameter systemParameter) {
        SystemParameterDAO dao = new SystemParameterDAO();
        Integer count = dao.delete(systemParameter.getSEQ());
        if (count > 0) {
            return true;
        } else {
            return false;
        }
    }

    public List<SystemParameter> selectAllUNITACCNUMworkUnit() {
        SystemParameterDAO dao = new SystemParameterDAO();
        List<SystemParameter> selectallUNITACCNUMworkUnit = dao.selectAllUNITACCNUM();
        System.out.println("selectworkUnit:::::::::::" + selectallUNITACCNUMworkUnit);
        if (selectallUNITACCNUMworkUnit != null) {
            return selectallUNITACCNUMworkUnit;
        } else {
            return null;
        }

    }






    public Pager<SystemParameter> findPersonByPage(String _currentPage, String _rows) {
        SystemParameterDAO dao = new SystemParameterDAO();
        int currentPage = Integer.parseInt(_currentPage);
        int rows = Integer.parseInt(_rows);

        Pager<SystemParameter> pb = new Pager<SystemParameter>();
        pb.setCurrentPage(currentPage);
        pb.setRows(rows);

        int totalCount = dao.findTotalCount();
        pb.setTotalCount(totalCount);
        int start = (currentPage - 1) * rows;
        List<SystemParameter> list = dao.findByPage(start, rows);
        pb.setList(list);

        int totalPage = (totalCount % rows) == 0 ? (totalCount / rows) : (totalCount / rows) + 1;
        pb.setTotalPage(totalPage);
        return pb;

    }












}
