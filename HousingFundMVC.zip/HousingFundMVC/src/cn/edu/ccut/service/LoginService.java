package cn.edu.ccut.service;

import cn.edu.ccut.dao.LoginDAO;
import cn.edu.ccut.po.Login;

public class LoginService {

    public boolean loginMethod(Login login) {
        LoginDAO dao = new LoginDAO();
        login = dao.query(login.getUsername(), login.getPassword());
        Integer id = login.getId();
        if (id != null) {
            return true;
        } else {
            return false;
        }
    }
}
