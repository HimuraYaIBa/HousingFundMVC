package cn.edu.ccut.service;
/*
UNITACCNAME 单位名称
UNITADDR  单位地址
ORGCODE  组织机构代码
UNITCHAR  单位类别
UNITKIND  企业类型
SALARYDATE  发薪日期
UNITPHONE  联系电话
UNITLINKMAN  单位联系人
UNITAGENTPAPNO  经办人身份证号码
UNITPROP  单位比例
PERPROP  个人比例
LASTPAYDATE 最新日期
REMARK  备注
*/

import cn.edu.ccut.dao.WorkUnitDAO;
import cn.edu.ccut.po.Pager;
import cn.edu.ccut.po.WorkUnit;

import java.util.ArrayList;
import java.util.List;

public class WorkUnitService {

    public boolean insertworkUnit(WorkUnit workUnit) {
        WorkUnitDAO dao = new WorkUnitDAO();
        Integer count = dao.insert(workUnit.getUNITACCNUM(),workUnit.getUNITACCNAME(), workUnit.getUNITADDR(), workUnit.getORGCODE(),
                workUnit.getUNITCHAR(), workUnit.getUNITKIND(), workUnit.getSALARYDATE(), workUnit.getUNITPHONE(),
                workUnit.getUNITLINKMAN(), workUnit.getUNITAGENTPAPNO(), workUnit.getUNITPROP(), workUnit.getPERPROP()
                , workUnit.getLASTPAYDATE(), workUnit.getREMARK());
        if (count > 0) {
            return true;
        } else {
            return false;
        }
    }


    public List<WorkUnit> selectworkUnit(WorkUnit workUnit) {
        WorkUnitDAO dao = new WorkUnitDAO();
        List<WorkUnit> selectworkUnit = dao.select(workUnit.getUNITACCNUM());
        System.out.println("selectworkUnit:::::::::::" + selectworkUnit);
        if (selectworkUnit != null) {
            return selectworkUnit;
        } else {
            return null;
        }

    }

    public List<WorkUnit> selectAllworkUnit() {
        WorkUnitDAO dao = new WorkUnitDAO();
        List<WorkUnit> selectallworkUnit = dao.selectAll();
        System.out.println("selectworkUnit:::::::::::" + selectallworkUnit);
        if (selectallworkUnit != null) {
            return selectallworkUnit;
        } else {
            return null;
        }

    }



    public boolean updateworkUnit(WorkUnit workUnit){
        WorkUnitDAO dao = new WorkUnitDAO();
        Integer count = dao.update(workUnit.getUNITACCNAME(), workUnit.getUNITADDR(), workUnit.getORGCODE(),
                workUnit.getUNITCHAR(), workUnit.getUNITKIND(), workUnit.getSALARYDATE(), workUnit.getUNITPHONE(),
                workUnit.getUNITLINKMAN(), workUnit.getUNITAGENTPAPNO(), workUnit.getUNITPROP(), workUnit.getPERPROP()
                , workUnit.getLASTPAYDATE(), workUnit.getREMARK(),workUnit.getUNITACCNUM());
        if (count > 0) {
            return true;
        } else {
            return false;
        }
    }







    public Pager<WorkUnit> findPersonByPage(String _currentPage, String _rows) {
        WorkUnitDAO dao = new WorkUnitDAO();
        int currentPage = Integer.parseInt(_currentPage);
        int rows = Integer.parseInt(_rows);

        Pager<WorkUnit> pb = new Pager<WorkUnit>();
        pb.setCurrentPage(currentPage);
        pb.setRows(rows);

        int totalCount = dao.findTotalCount();
        pb.setTotalCount(totalCount);
        int start = (currentPage - 1) * rows;
        List<WorkUnit> list = dao.findByPage(start, rows);
        pb.setList(list);

        int totalPage = (totalCount % rows) == 0 ? (totalCount / rows) : (totalCount / rows) + 1;
        pb.setTotalPage(totalPage);
        return pb;

    }


    public List<WorkUnit> selectAllUNITACCNUMworkPerson() {

        WorkUnitDAO dao = new WorkUnitDAO();
        List<WorkUnit> selectAllUNITACCNUMworkPerson = dao.selectAllUNITACCNUM();
        System.out.println("selectworkUnit:::::::::::" + selectAllUNITACCNUMworkPerson);
        if (selectAllUNITACCNUMworkPerson != null) {
            return selectAllUNITACCNUMworkPerson;
        } else {
            return null;
        }


    }
}


