package cn.edu.ccut.service;


import cn.edu.ccut.dao.WorkPersonDAO;
import cn.edu.ccut.po.Pager;
import cn.edu.ccut.po.WorkPerson;

import java.util.List;

public class WorkPersonService {


    public List<WorkPerson> selectworkPerson(WorkPerson workPerson) {
        WorkPersonDAO dao = new WorkPersonDAO();
        List<WorkPerson> selectworkPerson = dao.select(workPerson.getUNITACCNUM());
        System.out.println("selectworkPerson:::::::::::" + selectworkPerson);
        if (selectworkPerson != null) {
            return selectworkPerson;
        } else {
            return null;
        }

    }

    public boolean insertworkPerson(WorkPerson workPerson) {
        WorkPersonDAO dao = new WorkPersonDAO();
        Integer count = dao.insert(workPerson.getACCNUM(), workPerson.getUNITACCNUM(), workPerson.getUNITACCNAME(),
                workPerson.getUNITPROP(), workPerson.getPERPROP(), workPerson.getUSERNAME(),
                workPerson.getDOCUMENTTYPE(), workPerson.getBASENUMBER(), workPerson.getDOCUMENTNUMBER());
        if (count > 0) {
            return true;
        } else {
            return false;
        }
    }


    public List<WorkPerson> selectworkPersonACCNUM(WorkPerson workPerson) {
        WorkPersonDAO dao = new WorkPersonDAO();
        List<WorkPerson> selectworkPerson = dao.selectACCNUM(workPerson.getACCNUM());
        System.out.println("selectworkPerson:::::::::::" + selectworkPerson);
        if (selectworkPerson != null) {
            return selectworkPerson;
        } else {
            return null;
        }

    }

    public boolean updateworkPerson(WorkPerson workPerson) {
        WorkPersonDAO dao = new WorkPersonDAO();
        Integer count = dao.update(workPerson.getUSERNAME(), workPerson.getDOCUMENTTYPE(), workPerson.getDOCUMENTNUMBER(), workPerson.getACCNUM());
        if (count > 0) {
            return true;
        } else {
            return false;
        }
    }

    public List<WorkPerson> selectAllworkPerson() {
        WorkPersonDAO dao = new WorkPersonDAO();
        List<WorkPerson> selectallworkperson = dao.selectAll();
        System.out.println("selectallworkperson:::::::::::" + selectallworkperson);
        if (selectallworkperson != null) {
            return selectallworkperson;
        } else {
            return null;
        }

    }











    public Pager<WorkPerson> findPersonByPage(String _currentPage, String _rows) {
        WorkPersonDAO dao = new WorkPersonDAO();
        int currentPage = Integer.parseInt(_currentPage);
        int rows = Integer.parseInt(_rows);

        Pager<WorkPerson> pb = new Pager<WorkPerson>();
        pb.setCurrentPage(currentPage);
        pb.setRows(rows);

        int totalCount = dao.findTotalCount();
        pb.setTotalCount(totalCount);
        int start = (currentPage - 1) * rows;
        List<WorkPerson> list = dao.findByPage(start, rows);
        pb.setList(list);

        int totalPage = (totalCount % rows) == 0 ? (totalCount / rows) : (totalCount / rows) + 1;
        pb.setTotalPage(totalPage);
        return pb;

    }












}
