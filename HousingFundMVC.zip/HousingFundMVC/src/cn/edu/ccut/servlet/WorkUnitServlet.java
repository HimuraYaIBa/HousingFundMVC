package cn.edu.ccut.servlet;
/*
UNITACCNAME 单位名称
UNITADDR  单位地址
ORGCODE  组织机构代码
UNITCHAR  单位类别
UNITKIND  企业类型
SALARYDATE  发薪日期
UNITPHONE  联系电话
UNITLINKMAN  单位联系人
UNITAGENTPAPNO  经办人身份证号码
UNITPROP  单位比例
PERPROP  个人比例
REMARK  备注
*/

import cn.edu.ccut.po.Pager;
import cn.edu.ccut.po.WorkUnit;
import cn.edu.ccut.service.WorkUnitService;
import org.apache.ibatis.session.SqlSession;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;


@WebServlet("/workUnitServlet")
public class WorkUnitServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        WorkUnitService workUnitService = new WorkUnitService();
        String flag = request.getParameter("flag");
        if ("0".equals(flag)) {

            try {
                String UNITACCNUM = new String(request.getParameter("UNITACCNUM").getBytes("ISO8859-1"), "utf-8");
                String UNITACCNAME = new String(request.getParameter("UNITACCNAME").getBytes("ISO8859-1"), "utf-8");
                String UNITADDR = new String(request.getParameter("UNITADDR").getBytes("ISO8859-1"), "utf-8");
                String ORGCODE = new String(request.getParameter("ORGCODE").getBytes("ISO8859-1"), "utf-8");
                String UNITCHAR = new String(request.getParameter("UNITCHAR").getBytes("ISO8859-1"), "utf-8");
                String UNITKIND = new String(request.getParameter("UNITKIND").getBytes("ISO8859-1"), "utf-8");
                String SALARYDATE = new String(request.getParameter("SALARYDATE").getBytes("ISO8859-1"), "utf-8");
                String UNITPHONE = new String(request.getParameter("UNITPHONE").getBytes("ISO8859-1"), "utf-8");
                String UNITLINKMAN = new String(request.getParameter("UNITLINKMAN").getBytes("ISO8859-1"), "utf-8");
                String UNITAGENTPAPNO = new String(request.getParameter("UNITAGENTPAPNO").getBytes("ISO8859-1"), "utf-8");
                String UNITPROP = new String(request.getParameter("UNITPROP").getBytes("ISO8859-1"), "utf-8");
                String PERPROP = new String(request.getParameter("PERPROP").getBytes("ISO8859-1"), "utf-8");
                String LASTPAYDATE = new String(request.getParameter("LASTPAYDATE").getBytes("ISO8859-1"), "utf-8");
                String REMARK = new String(request.getParameter("REMARK").getBytes("ISO8859-1"), "utf-8");
                //设置参数完毕

                WorkUnit workUnit = new WorkUnit();
                workUnit.setUNITACCNUM(Integer.parseInt(UNITACCNUM));
                workUnit.setUNITACCNAME(UNITACCNAME);
                workUnit.setUNITADDR(UNITADDR);
                workUnit.setORGCODE(ORGCODE);
                workUnit.setUNITCHAR(UNITCHAR);
                workUnit.setUNITKIND(UNITKIND);
                workUnit.setSALARYDATE(SALARYDATE);
                workUnit.setUNITPHONE(UNITPHONE);
                workUnit.setUNITLINKMAN(UNITLINKMAN);
                workUnit.setUNITAGENTPAPNO(UNITAGENTPAPNO);
                workUnit.setUNITPROP(Double.parseDouble(UNITPROP));
                workUnit.setPERPROP(Double.parseDouble(PERPROP));
                workUnit.setLASTPAYDATE(LASTPAYDATE);
                workUnit.setREMARK(REMARK);

                boolean insertFlag = workUnitService.insertworkUnit(workUnit);

                if (insertFlag) {
                    response.sendRedirect("Uaccountopen.jsp");
                } else {
                    response.sendRedirect("failure.jsp");
                }

            } catch (Exception e) {
                response.sendRedirect("Uaccountadderror.jsp");
            }
        } else if ("1".equals(flag)) {
            String UNITACCNUM = new String(request.getParameter("UNITACCNUM").getBytes("ISO8859-1"), "utf-8");
            WorkUnit workUnit = new WorkUnit();

            System.out.println("UNITACCNUM:::::::::::" + UNITACCNUM);
            workUnit.setUNITACCNUM(Integer.parseInt(UNITACCNUM));

            try {
                List<WorkUnit> updateFlag = workUnitService.selectworkUnit(workUnit);
                HttpSession session = request.getSession();
                if (session == null) {
                    session = request.getSession(true);
                }
                session.removeAttribute("workunits");
                session.setAttribute("workunits", updateFlag);
                response.sendRedirect("Uaccountupdatelist.jsp");

            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("exception.jsp");
            }

        } else if ("2".equals(flag)) {
            String UNITACCNAME = new String(request.getParameter("UNITACCNAME").getBytes("ISO8859-1"), "utf-8");
            String UNITADDR = new String(request.getParameter("UNITADDR").getBytes("ISO8859-1"), "utf-8");
            String ORGCODE = new String(request.getParameter("ORGCODE").getBytes("ISO8859-1"), "utf-8");
            String UNITCHAR = new String(request.getParameter("UNITCHAR").getBytes("ISO8859-1"), "utf-8");
            String UNITKIND = new String(request.getParameter("UNITKIND").getBytes("ISO8859-1"), "utf-8");
            String SALARYDATE = new String(request.getParameter("SALARYDATE").getBytes("ISO8859-1"), "utf-8");
            String UNITPHONE = new String(request.getParameter("UNITPHONE").getBytes("ISO8859-1"), "utf-8");
            String UNITLINKMAN = new String(request.getParameter("UNITLINKMAN").getBytes("ISO8859-1"), "utf-8");
            String UNITAGENTPAPNO = new String(request.getParameter("UNITAGENTPAPNO").getBytes("ISO8859-1"), "utf-8");
            String UNITPROP = new String(request.getParameter("UNITPROP").getBytes("ISO8859-1"), "utf-8");
            String PERPROP = new String(request.getParameter("PERPROP").getBytes("ISO8859-1"), "utf-8");
            String LASTPAYDATE = new String(request.getParameter("LASTPAYDATE").getBytes("ISO8859-1"), "utf-8");
            String REMARK = new String(request.getParameter("REMARK").getBytes("ISO8859-1"), "utf-8");
            String UNITACCNUM = new String(request.getParameter("UNITACCNUM").getBytes("ISO8859-1"), "utf-8");

            WorkUnit workUnit = new WorkUnit();
            workUnit.setUNITACCNAME(UNITACCNAME);
            workUnit.setUNITADDR(UNITADDR);
            workUnit.setORGCODE(ORGCODE);
            workUnit.setUNITCHAR(UNITCHAR);
            workUnit.setUNITKIND(UNITKIND);
            workUnit.setSALARYDATE(SALARYDATE);
            workUnit.setUNITPHONE(UNITPHONE);
            workUnit.setUNITLINKMAN(UNITLINKMAN);
            workUnit.setUNITAGENTPAPNO(UNITAGENTPAPNO);
            workUnit.setUNITPROP(Double.parseDouble(UNITPROP));
            workUnit.setPERPROP(Double.parseDouble(PERPROP));
            workUnit.setLASTPAYDATE(LASTPAYDATE);
            workUnit.setREMARK(REMARK);
            workUnit.setUNITACCNUM(Integer.parseInt(UNITACCNUM));

            boolean updateFlag = workUnitService.updateworkUnit(workUnit);
            if (updateFlag) {
                response.sendRedirect("Uaccountupdate.jsp");
            } else {
                response.sendRedirect("failure.jsp");
            }

        } else if ("3".equals(flag)) {

            try {
                String currentPage = request.getParameter("currentPage");//当前页码
                String rows = request.getParameter("rows");//每页显示条数
                HttpSession session = request.getSession();
                if (session == null) {
                    session = request.getSession(true);
                }
                workUnitService = new WorkUnitService();
                Pager<WorkUnit> pb = workUnitService.findPersonByPage(currentPage, rows);
                System.out.println(pb);
                session.removeAttribute("pb");
                session.setAttribute("pb", pb);
                response.sendRedirect("Uaccounttable.jsp");

            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("exception.jsp");
            }

        } else if ("4".equals(flag)) {


            try {
                List<WorkUnit> selectallUNITACCNUMFlag = workUnitService.selectAllUNITACCNUMworkPerson();
                HttpSession session = request.getSession();
                if (session == null) {
                    session = request.getSession(true);
                }
                session.removeAttribute("workunits");
                session.setAttribute("workunits", selectallUNITACCNUMFlag);
                response.sendRedirect("Paccountopen.jsp");
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("exception.jsp");
            }

        }            //---------在这里增加其他flag用else if

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
