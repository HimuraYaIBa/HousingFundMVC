package cn.edu.ccut.servlet;


import cn.edu.ccut.po.Pager;
import cn.edu.ccut.po.WorkPerson;
import cn.edu.ccut.service.WorkPersonService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/workPersonServlet")
public class WorkPersonServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        WorkPersonService workPersonService = new WorkPersonService();
        String flag = request.getParameter("flag");
        if ("0".equals(flag)) {
            try {
                String UNITACCNUM = new String(request.getParameter("UNITACCNUM").getBytes("ISO8859-1"), "utf-8");
                WorkPerson workPerson = new WorkPerson();
                System.out.println("UNITACCNUM:::::::::::" + UNITACCNUM);
                workPerson.setUNITACCNUM(Integer.parseInt(UNITACCNUM));
                List<WorkPerson> selectflag = workPersonService.selectworkPerson(workPerson);
                HttpSession session = request.getSession();
                if (session == null) {
                    session = request.getSession(true);
                }
                session.removeAttribute("workpersons");
                session.setAttribute("workpersons", selectflag);
                response.sendRedirect("Paccountinsertlist.jsp");
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("Paccountselectexception.jsp");
            }
        } else if ("1".equals(flag)) {

            try {
                String ACCNUM = new String(request.getParameter("ACCNUM").getBytes("ISO8859-1"), "utf-8");
                String UNITACCNUM = new String(request.getParameter("UNITACCNUM").getBytes("ISO8859-1"), "utf-8");
                String UNITACCNAME = new String(request.getParameter("UNITACCNAME").getBytes("ISO8859-1"), "utf-8");
                String UNITPROP = new String(request.getParameter("UNITPROP").getBytes("ISO8859-1"), "utf-8");
                String PERPROP = new String(request.getParameter("PERPROP").getBytes("ISO8859-1"), "utf-8");
                String USERNAME = new String(request.getParameter("USERNAME").getBytes("ISO8859-1"), "utf-8");
                String DOCUMENTTYPE = new String(request.getParameter("DOCUMENTTYPE").getBytes("ISO8859-1"), "utf-8");
                String BASENUMBER = new String(request.getParameter("BASENUMBER").getBytes("ISO8859-1"), "utf-8");
                String DOCUMENTNUMBER = new String(request.getParameter("DOCUMENTNUMBER").getBytes("ISO8859-1"), "utf-8");

                WorkPerson workPerson = new WorkPerson();
                workPerson.setACCNUM(Integer.parseInt(ACCNUM));
                workPerson.setUNITACCNUM(Integer.parseInt(UNITACCNUM));
                workPerson.setUNITACCNAME(UNITACCNAME);
                workPerson.setUNITPROP(Double.parseDouble(UNITPROP));
                workPerson.setPERPROP(Double.parseDouble(PERPROP));
                workPerson.setUSERNAME(USERNAME);
                workPerson.setDOCUMENTTYPE(Integer.parseInt(DOCUMENTTYPE));
                workPerson.setBASENUMBER(Double.parseDouble(BASENUMBER));
                workPerson.setDOCUMENTNUMBER(DOCUMENTNUMBER);

                boolean insertFlag = workPersonService.insertworkPerson(workPerson);

                if (insertFlag) {
                    response.sendRedirect("Paccountopen.jsp");
                } else {
                    response.sendRedirect("failure.jsp");
                }
            } catch (Exception e) {
                response.sendRedirect("Paccountadderror.jsp");
            }
        } else if ("2".equals(flag)) {
            String ACCNUM = request.getParameter("ACCNUM");
            WorkPerson workPerson = new WorkPerson();

            System.out.println("ACCNUM:::::::::::" + ACCNUM);
            workPerson.setACCNUM(Integer.parseInt(ACCNUM));

            try {
                List<WorkPerson> selectflag = workPersonService.selectworkPersonACCNUM(workPerson);
                HttpSession session = request.getSession();
                if (session == null) {
                    session = request.getSession(true);
                }
                session.removeAttribute("workpersons");
                session.setAttribute("workpersons", selectflag);
                response.sendRedirect("Paccountupdatelist.jsp");
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("exception.jsp");
            }

        } else if ("3".equals(flag)) {

            String USERNAME = new String(request.getParameter("USERNAME").getBytes("ISO8859-1"), "utf-8");
            String DOCUMENTTYPE = new String(request.getParameter("DOCUMENTTYPE").getBytes("ISO8859-1"), "utf-8");
            String DOCUMENTNUMBER = new String(request.getParameter("DOCUMENTNUMBER").getBytes("ISO8859-1"), "utf-8");
            String ACCNUM = new String(request.getParameter("ACCNUM").getBytes("ISO8859-1"), "utf-8");


            WorkPerson workPerson = new WorkPerson();
            workPerson.setUSERNAME(USERNAME);
            workPerson.setDOCUMENTTYPE(Integer.parseInt(DOCUMENTTYPE));
            workPerson.setDOCUMENTNUMBER(DOCUMENTNUMBER);
            workPerson.setACCNUM(Integer.parseInt(ACCNUM));

            boolean updateFlag = workPersonService.updateworkPerson(workPerson);

            if (updateFlag) {
                response.sendRedirect("Paccountupdate.jsp");
            } else {
                response.sendRedirect("failure.jsp");
            }


        } else if ("4".equals(flag)) {
            try {
                String currentPage = request.getParameter("currentPage");//当前页码
                String rows = request.getParameter("rows");//每页显示条数
                HttpSession session = request.getSession();
                if (session == null) {
                    session = request.getSession(true);
                }
                workPersonService = new WorkPersonService();
                Pager<WorkPerson> pb = workPersonService.findPersonByPage(currentPage, rows);
                System.out.println(pb);
                session.removeAttribute("pb");
                session.setAttribute("pb", pb);
                response.sendRedirect("Paccounttable.jsp");
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("exception.jsp");
            }


        }//添加else if

    }


    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }


}
