package cn.edu.ccut.servlet;


import cn.edu.ccut.po.Pager;
import cn.edu.ccut.po.SystemParameter;
import cn.edu.ccut.service.SystemParameterService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/systemParameterServlet")
public class SystemParameterServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        SystemParameterService systemParameterService = new SystemParameterService();
        String flag = request.getParameter("flag");
        if ("0".equals(flag)) {

            try {

                String currentPage = request.getParameter("currentPage");//当前页码
                String rows = request.getParameter("rows");//每页显示条数

                HttpSession session = request.getSession();
                if (session == null) {
                    session = request.getSession(true);
                }

                systemParameterService = new SystemParameterService();
                Pager<SystemParameter> pb = systemParameterService.findPersonByPage(currentPage, rows);

                System.out.println(pb);

                session.removeAttribute("pb");
                session.setAttribute("pb", pb);

                response.sendRedirect("SystemParamtable.jsp");

            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("exception.jsp");
            }


        } else if ("1".equals(flag)) {


            try {
                String SEQNAME = new String(request.getParameter("SEQNAME").getBytes("ISO8859-1"), "utf-8");
                String DESCE = new String(request.getParameter("DESCE").getBytes("ISO8859-1"), "utf-8");
                String FREEUSE1 = new String(request.getParameter("FREEUSE1").getBytes("ISO8859-1"), "utf-8");

                SystemParameter systemParameter = new SystemParameter();
                systemParameter.setSEQNAME(SEQNAME);
                systemParameter.setDESCE(DESCE);
                systemParameter.setFREEUSE1(FREEUSE1);

                boolean insertFlag = systemParameterService.insertsystemParameter(systemParameter);
                if (insertFlag) {
                    response.sendRedirect("systemParameterServlet?flag=0&currentPage=1&rows=5");
                } else {
                    response.sendRedirect("failure.jsp");
                }
            }catch (Exception e){
                response.sendRedirect("SystemParamadderror.jsp");
            }



        } else if ("2".equals(flag)) {
            String SEQNAME = new String(request.getParameter("SEQNAME").getBytes("ISO8859-1"), "utf-8");
            String DESCE = new String(request.getParameter("DESCE").getBytes("ISO8859-1"), "utf-8");
            String FREEUSE1 = new String(request.getParameter("FREEUSE1").getBytes("ISO8859-1"), "utf-8");
            String SEQ = new String(request.getParameter("SEQ").getBytes("ISO8859-1"), "utf-8");

            SystemParameter systemParameter = new SystemParameter();
            systemParameter.setSEQNAME(SEQNAME);
            systemParameter.setDESCE(DESCE);
            systemParameter.setFREEUSE1(FREEUSE1);
            systemParameter.setSEQ(Integer.parseInt(SEQ));
            boolean updateFlag = systemParameterService.updateworksystemParameter(systemParameter);

            if (updateFlag) {
                response.sendRedirect("systemParameterServlet?flag=0&currentPage=1&rows=5");
            } else {
                response.sendRedirect("failure.jsp");
            }

        } else if ("3".equals(flag)) {

            String SEQ = request.getParameter("SEQ");
            SystemParameter systemParameter = new SystemParameter();


            System.out.println("SEQ:::::::::::" + SEQ);
            systemParameter.setSEQ(Integer.parseInt(SEQ));

            try {
                List<SystemParameter> selectflag = systemParameterService.selectsystemParameter(systemParameter);
                HttpSession session = request.getSession();
                if (session == null) {
                    session = request.getSession(true);
                }
                session.removeAttribute("systemparameters");
                session.setAttribute("systemparameters", selectflag);
                response.sendRedirect("SystemParamupdate.jsp");

            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("exception.jsp");
            }

        } else if ("4".equals(flag)) {

            String SEQ = request.getParameter("SEQ");
            SystemParameter systemParameter = new SystemParameter();
            systemParameter.setSEQ(Integer.parseInt(SEQ));
            boolean deleteFlag = systemParameterService.deletesystemParameter(systemParameter);
            if (deleteFlag) {
                response.sendRedirect("systemParameterServlet?flag=0&currentPage=1&rows=5");
            } else {
                response.sendRedirect("failure.jsp");
            }

        } else if ("5".equals(flag)) {
            String selectid = request.getParameter("selectid");
            SystemParameter systemParameter = new SystemParameter();
            System.out.println("SEQ:::::::::::" + selectid);
            systemParameter.setSEQ(Integer.parseInt(selectid));
            try {
                List<SystemParameter> selectflag = systemParameterService.selectsystemParameter(systemParameter);
                HttpSession session = request.getSession();
                if (session == null) {
                    session = request.getSession(true);
                }
                session.removeAttribute("systemparameters");
                session.setAttribute("systemparameters", selectflag);
                response.sendRedirect("SystemParamtable.jsp");
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("exception.jsp");
            }
        } else if ("6".equals(flag)) {

            try {
                List<SystemParameter> selectallUNITACCNUMFlag = systemParameterService.selectAllUNITACCNUMworkUnit();
                HttpSession session = request.getSession();
                if (session == null) {
                    session = request.getSession(true);
                }
                session.removeAttribute("systemparamters");
                session.setAttribute("systemparamters", selectallUNITACCNUMFlag);
                response.sendRedirect("Uaccountopen.jsp");
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("exception.jsp");
            }


        }            //else if添加


    }


    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }


}
