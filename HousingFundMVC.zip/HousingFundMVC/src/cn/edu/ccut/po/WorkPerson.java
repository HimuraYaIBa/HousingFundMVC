package cn.edu.ccut.po;

import java.util.Date;

public class WorkPerson {
    private int ACCNUM;
    private int UNITACCNUM;
    private Date OPENDATE;
    private double BALANCE;
    private String PERACCSTATE;
    private double BASENUMBER;
    private double UNITPROP;
    private String LASTPAYDATE;
    private double UNITMONPAYSUM;
    private double PERMONPAYSUM;
    private double YPAYAMT;
    private double YDRAWAMT;
    private double YINTERESTBAL;
    private String INSTCODE;
    private String OP;
    private String REMARK;
    private String UNITACCNAME;
    private String USERNAME;
    private int DOCUMENTTYPE;
    private String DOCUMENTNUMBER;
    private double PERPROP;

    public double getPERPROP() {
        return PERPROP;
    }

    public void setPERPROP(double PERPROP) {
        this.PERPROP = PERPROP;
    }

    public int getACCNUM() {
        return ACCNUM;
    }

    public void setACCNUM(int ACCNUM) {
        this.ACCNUM = ACCNUM;
    }

    public int getUNITACCNUM() {
        return UNITACCNUM;
    }

    public void setUNITACCNUM(int UNITACCNUM) {
        this.UNITACCNUM = UNITACCNUM;
    }

    public Date getOPENDATE() {
        return OPENDATE;
    }

    public void setOPENDATE(Date OPENDATE) {
        this.OPENDATE = OPENDATE;
    }

    public double getBALANCE() {
        return BALANCE;
    }

    public void setBALANCE(double BALANCE) {
        this.BALANCE = BALANCE;
    }

    public String getPERACCSTATE() {
        return PERACCSTATE;
    }

    public void setPERACCSTATE(String PERACCSTATE) {
        this.PERACCSTATE = PERACCSTATE;
    }

    public double getBASENUMBER() {
        return BASENUMBER;
    }

    public void setBASENUMBER(double BASENUMBER) {
        this.BASENUMBER = BASENUMBER;
    }

    public double getUNITPROP() {
        return UNITPROP;
    }

    public void setUNITPROP(double UNITPROP) {
        this.UNITPROP = UNITPROP;
    }

    public String getLASTPAYDATE() {
        return LASTPAYDATE;
    }

    public void setLASTPAYDATE(String LASTPAYDATE) {
        this.LASTPAYDATE = LASTPAYDATE;
    }

    public double getUNITMONPAYSUM() {
        return UNITMONPAYSUM;
    }

    public void setUNITMONPAYSUM(double UNITMONPAYSUM) {
        this.UNITMONPAYSUM = UNITMONPAYSUM;
    }

    public double getPERMONPAYSUM() {
        return PERMONPAYSUM;
    }

    public void setPERMONPAYSUM(double PERMONPAYSUM) {
        this.PERMONPAYSUM = PERMONPAYSUM;
    }

    public double getYPAYAMT() {
        return YPAYAMT;
    }

    public void setYPAYAMT(double YPAYAMT) {
        this.YPAYAMT = YPAYAMT;
    }

    public double getYDRAWAMT() {
        return YDRAWAMT;
    }

    public void setYDRAWAMT(double YDRAWAMT) {
        this.YDRAWAMT = YDRAWAMT;
    }

    public double getYINTERESTBAL() {
        return YINTERESTBAL;
    }

    public void setYINTERESTBAL(double YINTERESTBAL) {
        this.YINTERESTBAL = YINTERESTBAL;
    }

    public String getINSTCODE() {
        return INSTCODE;
    }

    public void setINSTCODE(String INSTCODE) {
        this.INSTCODE = INSTCODE;
    }

    public String getOP() {
        return OP;
    }

    public void setOP(String OP) {
        this.OP = OP;
    }

    public String getREMARK() {
        return REMARK;
    }

    public void setREMARK(String REMARK) {
        this.REMARK = REMARK;
    }


    public String getUNITACCNAME() {
        return UNITACCNAME;
    }

    public void setUNITACCNAME(String UNITACCNAME) {
        this.UNITACCNAME = UNITACCNAME;
    }

    public String getUSERNAME() {
        return USERNAME;
    }

    public void setUSERNAME(String USERNAME) {
        this.USERNAME = USERNAME;
    }

    public int getDOCUMENTTYPE() {
        return DOCUMENTTYPE;
    }

    public void setDOCUMENTTYPE(int DOCUMENTTYPE) {
        this.DOCUMENTTYPE = DOCUMENTTYPE;
    }

    public String getDOCUMENTNUMBER() {
        return DOCUMENTNUMBER;
    }

    public void setDOCUMENTNUMBER(String DOCUMENTNUMBER) {
        this.DOCUMENTNUMBER = DOCUMENTNUMBER;
    }
}
