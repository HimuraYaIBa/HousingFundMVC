package cn.edu.ccut.po;

import java.io.Serializable;

public class SystemParameter{

    String SEQNAME;
    int SEQ;
    int MAXSEQ;
    String DESCE;
    String FREEUSE1;

    public String getSEQNAME() {
        return SEQNAME;
    }

    public void setSEQNAME(String SEQNAME) {
        this.SEQNAME = SEQNAME;
    }

    public int getSEQ() {
        return SEQ;
    }

    public void setSEQ(int SEQ) {
        this.SEQ = SEQ;
    }

    public int getMAXSEQ() {
        return MAXSEQ;
    }

    public void setMAXSEQ(int MAXSEQ) {
        this.MAXSEQ = MAXSEQ;
    }

    public String getDESCE() {
        return DESCE;
    }

    public void setDESCE(String DESCE) {
        this.DESCE = DESCE;
    }

    public String getFREEUSE1() {
        return FREEUSE1;
    }

    public void setFREEUSE1(String FREEUSE1) {
        this.FREEUSE1 = FREEUSE1;
    }

}
