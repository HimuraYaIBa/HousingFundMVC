package cn.edu.ccut.po;

import java.util.Date;

public class WorkUnit {
    private int UNITACCNUM;
    private String UNITACCNAME;
    private String UNITADDR;
    private String ORGCODE;
    private String UNITCHAR;
    private String UNITKIND;
    private String SALARYDATE;
    private String UNITPHONE;
    private String UNITLINKMAN;
    private String UNITAGENTPAPNO;
    private String ACCSTATE;
    private double BALANCE;
    private double BASENUMBER;
    private double UNITPROP;
    private double PERPROP;
    private double UNITPAYSUM;
    private double PERPAYSUM;
    private int PERSNUM;
    private String LASTPAYDATE;
    private String INSTCODE;
    private String OP;
    private Date CREATDATE;
    private String REMARK;

    public int getUNITACCNUM() {
        return UNITACCNUM;
    }

    public void setUNITACCNUM(int UNITACCNUM) {
        this.UNITACCNUM = UNITACCNUM;
    }

    public String getUNITACCNAME() {
        return UNITACCNAME;
    }

    public void setUNITACCNAME(String UNITACCNAME) {
        this.UNITACCNAME = UNITACCNAME;
    }

    public String getUNITADDR() {
        return UNITADDR;
    }

    public void setUNITADDR(String UNITADDR) {
        this.UNITADDR = UNITADDR;
    }

    public String getORGCODE() {
        return ORGCODE;
    }

    public void setORGCODE(String ORGCODE) {
        this.ORGCODE = ORGCODE;
    }

    public String getUNITCHAR() {
        return UNITCHAR;
    }

    public void setUNITCHAR(String UNITCHAR) {
        this.UNITCHAR = UNITCHAR;
    }

    public String getUNITKIND() {
        return UNITKIND;
    }

    public void setUNITKIND(String UNITKIND) {
        this.UNITKIND = UNITKIND;
    }

    public String getSALARYDATE() {
        return SALARYDATE;
    }

    public void setSALARYDATE(String SALARYDATE) {
        this.SALARYDATE = SALARYDATE;
    }

    public String getLASTPAYDATE() {
        return LASTPAYDATE;
    }

    public void setLASTPAYDATE(String LASTPAYDATE) {
        this.LASTPAYDATE = LASTPAYDATE;
    }

    public String getUNITPHONE() {
        return UNITPHONE;
    }

    public void setUNITPHONE(String UNITPHONE) {
        this.UNITPHONE = UNITPHONE;
    }

    public String getUNITLINKMAN() {
        return UNITLINKMAN;
    }

    public void setUNITLINKMAN(String UNITLINKMAN) {
        this.UNITLINKMAN = UNITLINKMAN;
    }

    public String getUNITAGENTPAPNO() {
        return UNITAGENTPAPNO;
    }

    public void setUNITAGENTPAPNO(String UNITAGENTPAPNO) {
        this.UNITAGENTPAPNO = UNITAGENTPAPNO;
    }

    public String getACCSTATE() {
        return ACCSTATE;
    }

    public void setACCSTATE(String ACCSTATE) {
        this.ACCSTATE = ACCSTATE;
    }

    public double getBALANCE() {
        return BALANCE;
    }

    public void setBALANCE(double BALANCE) {
        this.BALANCE = BALANCE;
    }

    public double getBASENUMBER() {
        return BASENUMBER;
    }

    public void setBASENUMBER(double BASENUMBER) {
        this.BASENUMBER = BASENUMBER;
    }

    public double getUNITPROP() {
        return UNITPROP;
    }

    public void setUNITPROP(double UNITPROP) {
        this.UNITPROP = UNITPROP;
    }

    public double getPERPROP() {
        return PERPROP;
    }

    public void setPERPROP(double PERPROP) {
        this.PERPROP = PERPROP;
    }

    public double getUNITPAYSUM() {
        return UNITPAYSUM;
    }

    public void setUNITPAYSUM(double UNITPAYSUM) {
        this.UNITPAYSUM = UNITPAYSUM;
    }

    public double getPERPAYSUM() {
        return PERPAYSUM;
    }

    public void setPERPAYSUM(double PERPAYSUM) {
        this.PERPAYSUM = PERPAYSUM;
    }

    public int getPERSNUM() {
        return PERSNUM;
    }

    public void setPERSNUM(int PERSNUM) {
        this.PERSNUM = PERSNUM;
    }

    public String getINSTCODE() {
        return INSTCODE;
    }

    public void setINSTCODE(String INSTCODE) {
        this.INSTCODE = INSTCODE;
    }

    public String getOP() {
        return OP;
    }

    public void setOP(String OP) {
        this.OP = OP;
    }

    public Date getCREATDATE() {
        return CREATDATE;
    }

    public void setCREATDATE(Date CREATDATE) {
        this.CREATDATE = CREATDATE;
    }

    public String getREMARK() {
        return REMARK;
    }

    public void setREMARK(String REMARK) {
        this.REMARK = REMARK;
    }
}
